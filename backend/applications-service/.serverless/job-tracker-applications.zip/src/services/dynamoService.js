"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteApplication = exports.updateApplication = exports.getApplicationById = exports.getApplicationsByUserId = exports.createApplication = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const uuid_1 = require("uuid");
// Initialize the DynamoDB DocumentClient
const dynamoDb = new aws_sdk_1.default.DynamoDB.DocumentClient();
const tableName = process.env.APPLICATIONS_TABLE || '';
/**
 * Create a new application in DynamoDB
 */
const createApplication = async (application) => {
    const timestamp = new Date().toISOString();
    const id = application.id || (0, uuid_1.v4)();
    const params = {
        TableName: tableName,
        Item: {
            ...application,
            id,
            createdAt: timestamp,
            updatedAt: timestamp
        }
    };
    await dynamoDb.put(params).promise();
    return params.Item;
};
exports.createApplication = createApplication;
/**
 * Get all applications for a specific user
 */
const getApplicationsByUserId = async (userId) => {
    const params = {
        TableName: tableName,
        IndexName: 'UserIdIndex',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
            ':userId': userId
        }
    };
    const result = await dynamoDb.query(params).promise();
    return (result.Items || []);
};
exports.getApplicationsByUserId = getApplicationsByUserId;
/**
 * Get a single application by ID and user ID
 */
const getApplicationById = async (id, userId) => {
    const params = {
        TableName: tableName,
        Key: { id }
    };
    const result = await dynamoDb.get(params).promise();
    // Verify the application belongs to the user
    if (!result.Item || result.Item.userId !== userId) {
        return null;
    }
    return result.Item;
};
exports.getApplicationById = getApplicationById;
/**
 * Update an existing application
 */
const updateApplication = async (id, updates, userId) => {
    // First, verify the application exists and belongs to the user
    const application = await (0, exports.getApplicationById)(id, userId);
    if (!application) {
        return null;
    }
    const timestamp = new Date().toISOString();
    // Build update expression and attribute values
    let updateExpression = 'SET updatedAt = :updatedAt';
    const expressionAttributeValues = {
        ':updatedAt': timestamp
    };
    // Add each updated field to the update expression
    Object.keys(updates).forEach((key) => {
        if (key !== 'id' && key !== 'userId' && key !== 'createdAt') {
            updateExpression += `, #${key} = :${key}`;
            expressionAttributeValues[`:${key}`] = updates[key];
        }
    });
    // Create expression attribute names for reserved words
    const expressionAttributeNames = {};
    Object.keys(updates).forEach((key) => {
        if (key !== 'id' && key !== 'userId' && key !== 'createdAt') {
            expressionAttributeNames[`#${key}`] = key;
        }
    });
    const params = {
        TableName: tableName,
        Key: { id },
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW'
    };
    const result = await dynamoDb.update(params).promise();
    return result.Attributes;
};
exports.updateApplication = updateApplication;
/**
 * Delete an application by ID
 */
const deleteApplication = async (id, userId) => {
    // First, verify the application exists and belongs to the user
    const application = await (0, exports.getApplicationById)(id, userId);
    if (!application) {
        return false;
    }
    const params = {
        TableName: tableName,
        Key: { id }
    };
    await dynamoDb.delete(params).promise();
    return true;
};
exports.deleteApplication = deleteApplication;
//# sourceMappingURL=dynamoService.js.map