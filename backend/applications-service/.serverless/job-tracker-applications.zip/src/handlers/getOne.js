"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamoService_1 = require("../services/dynamoService");
const authUtils_1 = require("../utils/authUtils");
/**
 * Get a specific job application by ID
 */
const handler = async (event) => {
    var _a;
    try {
        // Get user ID from authentication token
        const userId = (0, authUtils_1.getUserIdFromEvent)(event);
        // Get application ID from path parameters
        const id = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!id) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application ID is required'), 400);
        }
        // Get application from DynamoDB
        const application = await (0, dynamoService_1.getApplicationById)(id, userId);
        // Check if application exists and belongs to the user
        if (!application) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application not found'), 404);
        }
        // Return the application
        return (0, authUtils_1.formatResponse)(200, application);
    }
    catch (error) {
        return (0, authUtils_1.formatErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=getOne.js.map