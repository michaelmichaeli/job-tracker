"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamoService_1 = require("../services/dynamoService");
const authUtils_1 = require("../utils/authUtils");
/**
 * Delete a job application
 */
const handler = async (event) => {
    var _a;
    try {
        // Get user ID from authentication token
        const userId = (0, authUtils_1.getUserIdFromEvent)(event);
        // Get application ID from path parameters
        const id = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!id) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application ID is required'), 400);
        }
        // Delete from DynamoDB
        const success = await (0, dynamoService_1.deleteApplication)(id, userId);
        // Check if application exists and belongs to the user
        if (!success) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application not found or permission denied'), 404);
        }
        // Return success response
        return (0, authUtils_1.formatResponse)(204, null);
    }
    catch (error) {
        return (0, authUtils_1.formatErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=delete.js.map