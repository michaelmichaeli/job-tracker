"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const application_1 = require("../models/application");
const dynamoService_1 = require("../services/dynamoService");
const authUtils_1 = require("../utils/authUtils");
/**
 * Update an existing job application
 */
const handler = async (event) => {
    var _a;
    try {
        // Get user ID from authentication token
        const userId = (0, authUtils_1.getUserIdFromEvent)(event);
        // Get application ID from path parameters
        const id = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id;
        if (!id) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application ID is required'), 400);
        }
        // Parse request body
        const updates = event.body ? JSON.parse(event.body) : {};
        // Make sure the ID in the path matches the body if provided
        if (updates.id && updates.id !== id) {
            return (0, authUtils_1.formatErrorResponse)(new Error('ID in the path does not match ID in the body'), 400);
        }
        // Ensure userId cannot be changed
        if (updates.userId && updates.userId !== userId) {
            return (0, authUtils_1.formatErrorResponse)(new Error('User ID cannot be changed'), 403);
        }
        // Set the correct ID and userId for validation
        updates.id = id;
        updates.userId = userId;
        // Validate the update data
        const { error, value } = (0, application_1.validateApplication)(updates);
        if (error) {
            return (0, authUtils_1.formatErrorResponse)(error, 400);
        }
        // Update in DynamoDB
        const updatedApplication = await (0, dynamoService_1.updateApplication)(id, value, userId);
        // Check if application exists and belongs to the user
        if (!updatedApplication) {
            return (0, authUtils_1.formatErrorResponse)(new Error('Application not found or permission denied'), 404);
        }
        // Return the updated application
        return (0, authUtils_1.formatResponse)(200, updatedApplication);
    }
    catch (error) {
        return (0, authUtils_1.formatErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=update.js.map