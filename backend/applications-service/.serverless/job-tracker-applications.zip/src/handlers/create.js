"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const application_1 = require("../models/application");
const dynamoService_1 = require("../services/dynamoService");
const authUtils_1 = require("../utils/authUtils");
/**
 * Create a new job application
 */
const handler = async (event) => {
    try {
        // Get user ID from authentication token
        const userId = (0, authUtils_1.getUserIdFromEvent)(event);
        // Parse request body
        const applicationData = event.body ? JSON.parse(event.body) : {};
        // Add the userId to the application data
        applicationData.userId = userId;
        // Validate the application data
        const { error, value } = (0, application_1.validateApplication)(applicationData);
        if (error) {
            return (0, authUtils_1.formatErrorResponse)(error, 400);
        }
        // Save to DynamoDB
        const application = await (0, dynamoService_1.createApplication)(value);
        // Return the created application
        return (0, authUtils_1.formatResponse)(201, application);
    }
    catch (error) {
        return (0, authUtils_1.formatErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=create.js.map