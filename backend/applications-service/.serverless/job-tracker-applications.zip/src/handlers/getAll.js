"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamoService_1 = require("../services/dynamoService");
const authUtils_1 = require("../utils/authUtils");
/**
 * Get all job applications for the authenticated user
 */
const handler = async (event) => {
    try {
        // Get user ID from authentication token
        const userId = (0, authUtils_1.getUserIdFromEvent)(event);
        // Get applications from DynamoDB
        const applications = await (0, dynamoService_1.getApplicationsByUserId)(userId);
        // Return the applications
        return (0, authUtils_1.formatResponse)(200, applications);
    }
    catch (error) {
        return (0, authUtils_1.formatErrorResponse)(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=getAll.js.map