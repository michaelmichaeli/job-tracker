"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatErrorResponse = exports.formatResponse = exports.getUserIdFromEvent = void 0;
/**
 * Extract the user ID from the Cognito JWT token
 */
const getUserIdFromEvent = (event) => {
    var _a, _b, _c;
    // Cognito adds user claims in requestContext.authorizer.claims
    if ((_c = (_b = (_a = event.requestContext) === null || _a === void 0 ? void 0 : _a.authorizer) === null || _b === void 0 ? void 0 : _b.claims) === null || _c === void 0 ? void 0 : _c.sub) {
        // The "sub" claim in the token represents the Cognito user ID
        return event.requestContext.authorizer.claims.sub;
    }
    // For local development with serverless-offline
    if (process.env.IS_OFFLINE) {
        return 'test-user-id';
    }
    throw new Error('User ID not found in token');
};
exports.getUserIdFromEvent = getUserIdFromEvent;
/**
 * Format standardized API response
 */
const formatResponse = (statusCode, body) => {
    return {
        statusCode,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
    };
};
exports.formatResponse = formatResponse;
/**
 * Format error response
 */
const formatErrorResponse = (error, statusCode = 500) => {
    console.error('Error:', error);
    return (0, exports.formatResponse)(statusCode, {
        error: error.message || 'Unknown error',
        statusCode
    });
};
exports.formatErrorResponse = formatErrorResponse;
//# sourceMappingURL=authUtils.js.map